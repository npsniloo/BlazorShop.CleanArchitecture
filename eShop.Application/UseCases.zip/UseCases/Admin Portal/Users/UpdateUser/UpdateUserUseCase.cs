using eShop.Application.Interfaces.Repository;
using eShop.Domain.Entities;

namespace eShop.Application.UseCases.Admin_Portal.Users
{
    public class UpdateUserUseCase : IUpdateUserUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public UpdateUserUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task ExecuteAsync(UpdateUserCommand command)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            var repository = unitOfWork.GetRepository<User, int>();
            var user = await repository.GetByIdAsync(command.User.Id);
            if (user == null)
                return;

            // TODO: map User-specific fields here
            await unitOfWork.SaveChangesAsync();
        }
    }
}
