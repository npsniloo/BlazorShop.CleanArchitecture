﻿using eShop.Application.Interfaces.Repository;
using eShop.Domain.Entities;

namespace eShop.Application.UseCases.Admin_Portal.Coupons
{
    public class DeleteCouponUseCase : IDeleteCouponUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public DeleteCouponUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task ExecuteAsync(int id)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            var repository = unitOfWork.GetRepository<Coupon, int>();
            var coupon = await repository.GetByIdAsync(id);
            if (coupon == null)
                return;            
            repository.Remove(coupon);
            await unitOfWork.SaveChangesAsync();

        }
    }
}
