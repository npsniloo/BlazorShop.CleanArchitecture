﻿using eShop.Application.Interfaces.Repository;
using eShop.Domain.Entities;

namespace eShop.Application.UseCases.Admin_Portal.Menus
{
    public class DeleteMenuUseCase : IDeleteMenuUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public DeleteMenuUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task ExecuteAsync(int id)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            var repository = unitOfWork.GetRepository<Menu, int>();
            var menu = await repository.GetByIdAsync(id);
            if (menu == null)
                return;            
            repository.Remove(menu);
            await unitOfWork.SaveChangesAsync();

        }
    }
}
