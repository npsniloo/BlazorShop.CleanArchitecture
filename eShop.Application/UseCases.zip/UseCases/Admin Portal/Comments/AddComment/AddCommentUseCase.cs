﻿using eShop.Application.Interfaces.Repository;
using eShop.Application.Interfaces.Services;
using eShop.Domain.Entities;

namespace eShop.Application.UseCases.Admin_Portal.Comments
{
    public class AddCommentUseCase : IAddCommentUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public AddCommentUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task ExecuteAsync(AddCommentCommand command)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            var repository = unitOfWork.GetRepository<Comment, int>();
            await repository.AddAsync(command.Comment);
            await unitOfWork.SaveChangesAsync();
        }
    }
}
