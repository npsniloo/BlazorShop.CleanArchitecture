﻿using eShop.Application.Interfaces.Repository;
using eShop.Application.Interfaces.Services;
using eShop.Domain.Entities;

namespace eShop.Application.UseCases.Admin_Portal.Banners
{
    public class UpdateBannerUseCase : IUpdateBannerUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public UpdateBannerUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }
        public async Task ExecuteAsync(UpdateBannerCommand command)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            var repository = unitOfWork.GetRepository<Banner, int>();
            var bnr = await repository.GetByIdAsync(command.Banner.Id);
            if (bnr == null)
                return;
            

            bnr.Title = command.Banner.Title;
            bnr.Link = command.Banner.Link;
            bnr.Priority = command.Banner.Priority;
            bnr.Position = command.Banner.Position;
            bnr.Title = command.Banner.Title;
            bnr.SubTitle = command.Banner.SubTitle;
            bnr.Position = command.Banner.Position;
            await unitOfWork.SaveChangesAsync();
        }
    }
}
