﻿using eShop.Application.Interfaces.Repository;
using eShop.Domain.Entities;

namespace eShop.Application.UseCases.Admin_Portal.Orders
{
    public class AddOrderUseCase : IAddOrderUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public AddOrderUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task ExecuteAsync(AddOrderCommand command)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            var repository = unitOfWork.GetRepository<Order, int>();
            await repository.AddAsync(command.Order);
            await unitOfWork.SaveChangesAsync();
        }
    }
}
