﻿using eShop.Application.Interfaces.Repository;
using eShop.Domain.Entities;

namespace eShop.Application.UseCases.Admin_Portal.Products  
{
    public class DeleteGalleryUseCase : IDeleteGalleryUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public DeleteGalleryUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task ExecuteAsync(int id)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            var repository = unitOfWork.GetRepository<ProductGallery, int>();
            var gallery = await repository.GetByIdAsync(id);
            
            if (gallery == null)
                throw new Exception("gallery doesn't exist");

            repository.Remove(gallery);
            await unitOfWork.SaveChangesAsync();
        }
    }
}
