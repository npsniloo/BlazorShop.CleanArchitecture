﻿using eShop.Application.Interfaces.Repository;
using eShop.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eShop.Application.UseCases.Customer_Portal
{
    public class AddOrderDetailUseCase : IAddOrderDetailUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public AddOrderDetailUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task ExecuteAsync(List<OrderDetail> orderDetails)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            var orderRepository = unitOfWork.GetRepository<OrderDetail, int>();
            foreach (var item in orderDetails)
            {
                await orderRepository.AddAsync(item);
            }
            await unitOfWork.SaveChangesAsync();
        }
    }
}
