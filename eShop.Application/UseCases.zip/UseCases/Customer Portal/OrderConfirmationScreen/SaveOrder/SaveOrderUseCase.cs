﻿using eShop.Application.Interfaces.Repository;
using eShop.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eShop.Application.UseCases.Customer_Portal
{
    public class SaveOrderUseCase : ISaveOrderUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public SaveOrderUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task ExecuteAsync(Order order)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            await unitOfWork.OrderRepository.AddAsync(order);
            await unitOfWork.SaveChangesAsync();

        }
    }
}
