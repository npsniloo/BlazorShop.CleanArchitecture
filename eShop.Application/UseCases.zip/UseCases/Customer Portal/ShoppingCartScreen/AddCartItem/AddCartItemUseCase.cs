﻿using eShop.Application.Interfaces.Repository;
using eShop.Domain.Entities;

namespace eShop.Application.UseCases.Customer_Portal
{
    internal class AddCartItemUseCase : IAddCartItemUseCase
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public AddCartItemUseCase(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task ExecuteAsync(Cart cart)
        {
            using var unitOfWork = await _unitOfWorkFactory.CreateAsync();
            await unitOfWork.CartRepository.AddAsync(cart);
            await unitOfWork.SaveChangesAsync();
        }
    }
}
